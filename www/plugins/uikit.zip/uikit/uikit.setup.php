<?php
/* ====================
[BEGIN_COT_EXT]
Code=uikit 
Name=UIkit 
Category=interface
Description=A lightweight and modular front-end framework for developing fast and powerful web interfaces.
Version=2.23.0
Date=2015-09-07
Author=Flancer Team
Copyright=Copyright (c) Flancer Team 2015
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=R
Lock_members=
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');
